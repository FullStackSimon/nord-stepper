import{_ as o}from"./custom-element-CrijKA9J.js";import{n as t}from"./property-D6aRJ58V.js";function e(e){class r extends e{constructor(){super(...arguments),this.autocomplete="off"}}return o([t()],r.prototype,"autocomplete",void 0),r}export{e as A};
//# sourceMappingURL=AutocompleteMixin-C_tXVTkf.js.map
