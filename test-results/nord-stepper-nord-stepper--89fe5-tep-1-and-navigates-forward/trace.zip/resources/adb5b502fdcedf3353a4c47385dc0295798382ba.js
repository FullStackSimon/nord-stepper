function n(n,t,r){return n>r?t:n<t?r:n}function t(n,t){const r=[];for(let u=n;u<=t;u++)r.push(u);return r}function r(n,t,r){return Math.max(t,Math.min(n,r))}export{r as c,t as r,n as w};
//# sourceMappingURL=number-Dg2vCfGd.js.map
