const e={prevMonthLabel:"Previous month",nextMonthLabel:"Next month",monthSelectLabel:"Month",yearSelectLabel:"Year"};export{e as default};
//# sourceMappingURL=localization3.js.map
