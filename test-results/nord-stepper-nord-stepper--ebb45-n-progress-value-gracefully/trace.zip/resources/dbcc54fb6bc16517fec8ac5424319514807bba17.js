const s={dismissLabel:"Dismiss notification"};export{s as default};
//# sourceMappingURL=localization7.js.map
