function n(n){return{transition:(t,r)=>n[t][r]||t}}export{n as f};
//# sourceMappingURL=fsm-Bq5jMQrK.js.map
