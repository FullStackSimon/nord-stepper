import{E as t}from"./lit-element-CDJJjKCD.js";
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const e=e=>e??t;export{e as o};
//# sourceMappingURL=if-defined-Du4H0BGt.js.map
