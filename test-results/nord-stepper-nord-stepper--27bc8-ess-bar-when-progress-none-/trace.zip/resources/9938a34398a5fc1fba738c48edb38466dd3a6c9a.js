const e={modalHeading:"Choose a date",closeLabel:"Close window",buttonLabel:"Choose date",selectedDateMessage:"Selected date is"};export{e as default};
//# sourceMappingURL=localization2.js.map
