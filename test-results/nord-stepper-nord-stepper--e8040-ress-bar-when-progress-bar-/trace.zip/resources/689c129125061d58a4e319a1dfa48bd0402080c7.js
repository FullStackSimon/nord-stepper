const e={removeLabel:"Remove"};export{e as default};
//# sourceMappingURL=localization9.js.map
