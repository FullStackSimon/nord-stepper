import{n as t}from"./property-D6aRJ58V.js";
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function r(r){return t({...r,state:!0,attribute:!1})}export{r};
//# sourceMappingURL=state-CLy7bemX.js.map
