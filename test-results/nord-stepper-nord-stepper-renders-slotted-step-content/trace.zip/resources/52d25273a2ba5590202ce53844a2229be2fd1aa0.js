import{E as t}from"./lit-element-CDJJjKCD.js";function e(e,r=e,n=t){return e?r:n}export{e as c};
//# sourceMappingURL=cond-BRE9RD0P.js.map
