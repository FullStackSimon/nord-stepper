import{p as a,a as s}from"./dates-lbaNvUdr.js";const o={parse:a,format:s};export{o as isoAdapter};
//# sourceMappingURL=date-adapter.js.map
