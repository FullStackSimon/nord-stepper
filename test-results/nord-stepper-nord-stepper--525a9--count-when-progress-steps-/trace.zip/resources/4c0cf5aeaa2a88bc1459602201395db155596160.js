import{B as t}from"./lit-element-CDJJjKCD.js";class o{constructor(t,o){this.host=t,this.options=o,t.addController(this)}get container(){return this.options.container||this.host}hostUpdated(){this.render()}render(){t(this.options.render(),this.container,this.options.renderOptions)}}export{o as L};
//# sourceMappingURL=LightDomController-BIiLqdFB.js.map
