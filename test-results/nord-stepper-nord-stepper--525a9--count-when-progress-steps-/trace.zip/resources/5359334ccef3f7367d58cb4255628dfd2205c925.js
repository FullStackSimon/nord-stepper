const a={unreadLabel:"Unread"};export{a as default};
//# sourceMappingURL=localization8.js.map
