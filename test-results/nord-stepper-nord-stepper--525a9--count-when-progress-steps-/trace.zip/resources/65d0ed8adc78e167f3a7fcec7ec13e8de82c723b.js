const a={remainingCharacters:a=>`Characters remaining: ${a}`};export{a as default};
//# sourceMappingURL=localization6.js.map
