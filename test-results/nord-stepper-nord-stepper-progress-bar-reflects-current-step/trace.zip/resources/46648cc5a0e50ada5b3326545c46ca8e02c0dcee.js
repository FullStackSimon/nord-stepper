class s{constructor(s){this.listeners=[],s.addController(this)}hostDisconnected(){this.listeners.forEach((s=>s())),this.listeners=[]}listen(s,e,t,n){null==s||s.addEventListener(e,t,n);this.listeners.push((()=>null==s?void 0:s.removeEventListener(e,t,n)))}}export{s as E};
//# sourceMappingURL=EventController-BBOmvfLa.js.map
