import{_ as t}from"./custom-element-CrijKA9J.js";import{n as e}from"./property-D6aRJ58V.js";function r(r){class o extends r{constructor(){super(...arguments),this.size="m"}}return t([e({reflect:!0})],o.prototype,"size",void 0),o}export{r as S};
//# sourceMappingURL=SizeMixin-M_o6N_Tr.js.map
