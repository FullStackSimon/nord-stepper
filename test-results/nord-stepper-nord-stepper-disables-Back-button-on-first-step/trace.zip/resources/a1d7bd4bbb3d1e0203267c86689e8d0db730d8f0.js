const e={closeLabel:"Close dialog"};export{e as default};
//# sourceMappingURL=localization4.js.map
