import{N as e}from"./events-Bv6wNHwJ.js";class s extends e{constructor(e){super(s.eventName),this.command=e}}s.eventName="nord-select";export{s as SelectEvent};
//# sourceMappingURL=SelectEvent.js.map
