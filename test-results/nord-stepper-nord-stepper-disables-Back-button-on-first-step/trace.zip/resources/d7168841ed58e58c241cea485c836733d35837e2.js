const a={label:"Toggle navigation"};export{a as default};
//# sourceMappingURL=localization5.js.map
