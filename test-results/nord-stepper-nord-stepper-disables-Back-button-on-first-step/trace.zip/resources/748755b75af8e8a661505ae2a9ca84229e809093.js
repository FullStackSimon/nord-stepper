import{N as s}from"./events-Bv6wNHwJ.js";class t extends s{constructor(s,t){super(s),this.date=t}}export{t as DateSelectEvent};
//# sourceMappingURL=DateSelectEvent.js.map
